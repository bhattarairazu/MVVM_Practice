package com.example.razu.mvvm_practice.model;

public class Game {
}
