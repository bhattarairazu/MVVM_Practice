package com.example.razu.mvvm_practice.utilties;

public class StringUtility {
public static boolean isNullOrEmpty(String valeu){
    return valeu == null || valeu.length() == 0;
}

}
