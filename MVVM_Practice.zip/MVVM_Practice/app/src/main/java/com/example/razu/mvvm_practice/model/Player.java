package com.example.razu.mvvm_practice.model;

public class Player {
    public String name;
    public String value;

    public Player(String name, String value) {
        this.name = name;
        this.value = value;
    }
}
